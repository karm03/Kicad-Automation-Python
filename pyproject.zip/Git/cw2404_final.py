import argparse
import uuid
from kiutils.schematic import Schematic
from kiutils.items.schitems import Text
from kiutils.items.common import Effects, Font, Justify, Position
# from collections import namedtuple


# Define the structure
# PinData = namedtuple('PinData', ['device_id', 'x_position', 'y_position', 'Angle', 'pin_no', 'pin_func', 'x_pin_pos', 'y_pin_pos', 'pin_angle'])

'''
0    180   
+90  0
-90  90
180  90


Res mirror x 90 =  text 0
Res mirror x 0  = text 90
Res mirror x 270 =  text 0
Res mirror y 0  = text 90



led 270 =  text 90
led 0  = text 0
led 90 =  text = 90
led 180 = 0
'''


def extract_pin_positions(schematics):
    lib_positions = {}
    pin_positions = []

    for schematic in schematics:
        if hasattr(schematic, 'schematicSymbols'):
            for symbol in schematic.schematicSymbols:
                if hasattr(symbol, 'libId') and hasattr(symbol, 'position'):
                    pos = symbol.position
                    angle = symbol.position.angle if hasattr(
                        symbol.position, 'angle') else 0
                    lib_positions[symbol.libId] = (pos.X, pos.Y, angle)

        if hasattr(schematic, 'libSymbols'):
            for symbol in schematic.libSymbols:
                for unit in symbol.units:
                    if hasattr(unit, 'pins'):
                        for pin in unit.pins:
                            pos = pin.position
                            # pin_angle = getattr(pin, 'angle', 0)
                            pin_positions.append(
                                (symbol.libId, pin.number, pin.name, pos.X, pos.Y, pos.angle))

    return lib_positions, pin_positions


def rotate_point(x, y, angle):
    """Rotate point (x, y) around the origin by angle degrees."""
    from math import radians, cos, sin
    print("    X = {}, Y = {}, Angle = {}".format(x, y, angle))
    angle_rad = radians(angle)
    x_new = x * cos(angle_rad) - y * sin(angle_rad)
    y_new = x * sin(angle_rad) + y * cos(angle_rad)
    print("    angle_rad = {}, x_new = {}, y_new = {}".format(angle_rad, x_new, y_new))
    if y_new < 0:
        y_new = -y_new  # Make negative value positive
    else:
        y_new = -y_new  # Make positive value negative
    return x_new, y_new

def print_pin_information(lib_positions, pin_positions):
    printed_libs = set()

    for libId, (lib_X, lib_Y, lib_angle) in lib_positions.items():
        if libId not in printed_libs:
            print("Library ID: {}".format(libId))
            print("  Position: X = {:.2}, Y = {:.2}, Angle = {}".format(lib_X, lib_Y, lib_angle))
            print("  Pins:")
            for pin_libId, pin_number, pin_name, pin_X, pin_Y, pin_angle in pin_positions:
                if pin_libId == libId:
                    # Rotate pin position relative to symbol
                    rotated_X, rotated_Y = rotate_point(pin_X, pin_Y, lib_angle)
                    # Sum positions to get the absolute position
                    sum_X = lib_X + rotated_X
                    sum_Y = lib_Y + rotated_Y
                    print("    Pin {}: Value = {}, X = {}, Y = {}, Angle = {}".format(pin_number, pin_name, sum_X, sum_Y, pin_angle))
            print()  # Print a blank line for separation between library IDs
            printed_libs.add(libId)


def print_text_details(text, pin_name, orientation):
    print("     New Text Details: ")
    print("         Pin {} ({}): ".format(pin_name, orientation))
    print("             Text: {}".format(text.text))
    print("             Position: {}".format(text.position))
    print("             UUID: {}".format(text.uuid))


def schematic_extraction_details():
    # Function to add new text to a schematic
    def add_text_to_schematic(schematic, file_name, Symbol_positions):
        # print(f"inside add_text_to_schematic X = {sum_X}, Y = {sum_Y}, Angle = {angle}")
        '''
            1. Takes the schematic and its file name as an argument.
            2. Then asks the user to add new text.
            3. Then asks what text and the positions of it.
            4. Then updates the file and new text will be added.

            :param schematic: first paramater to take schematic file
            :param file_name: second paramater to take the name of the file

        '''
        def add_text_to_pins(schematic, new_text_string, symbol_positions):
            added_positions = set()  # To track positions where text has been added

            for (entryName, sum_X, sum_Y, angle, pin_angle) in symbol_positions:
                symbol_name = {entryName: (X, Y, SYM_ANG, PIN_ANG) for entryName, X, Y, SYM_ANG, PIN_ANG in symbol_positions}
                if entryName in symbol_name:

                    pos_key = (sum_X, sum_Y, angle, pin_angle)
                    if pos_key in added_positions:
                        # Skip if this position has already had text added
                        continue

                    print("Processing " + entryName)
                    print("     Pos pin: ", sum_X, sum_Y, angle, pin_angle)

                    if (pin_angle == 90 or pin_angle == 270):
                        if (angle == 0 or angle == 180):
                            print("     Output: 90")
                            len_txt = len(new_text_string)
                            if(pin_angle == 90 and angle == 0):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y + (len_txt - 1)
                            if(pin_angle == 90 and angle == 180):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y - 0.1#(len_txt - 1)
                            if(pin_angle == 270 and angle == 180):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y + (len_txt - 1)
                            if(pin_angle == 270 and angle == 0):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y - 0.1# (len_txt - 1)
                            #text_pin_X = sum_X - (len_txt - 1)
                            #text_pin_Y = sum_Y + 0.09
                            justification = Justify('left', 'bottom', 'center')
                            position = Position(X=round(text_pin_X,2), Y=round(text_pin_Y,2), angle=90)
                            text = Text(new_text_string, position, Effects(Font(), justification), uuid.uuid4())
                            print_text_details(text, '1', 'horizontal')
                            schematic.texts.append(text)
                        elif (angle == 90 or angle == 270):
                            print("     Output: 0")
                            text_len = len(new_text_string)
                            #print(text_len)
                            text_pin_X = sum_X
                            text_pin_Y = sum_Y
                            if(pin_angle == 90 and angle == 90):
                                text_pin_X = sum_X + 0.1 #
                                text_pin_Y = sum_Y - 0.1
                            if(pin_angle == 270 and angle == 270):
                                text_pin_X = sum_X + 0.1 #
                                text_pin_Y = sum_Y - 0.1
                            if(pin_angle == 90 and angle == 270):
                                text_pin_X = sum_X - (text_len - 1) #
                                text_pin_Y = sum_Y - 0.1
                            if(pin_angle == 270 and angle == 90):
                                text_pin_X = sum_X - (text_len - 1) #
                                text_pin_Y = sum_Y - 0.1
                               # text_pin_X = sum_X - (text_len - 1) #
                              #  text_pin_Y = sum_Y - 0.1
                            justification = Justify('left', 'bottom', 'center')
                            position = Position(X=round(text_pin_X,2), Y=round(text_pin_Y,2), angle=0)
                            text = Text(new_text_string, position, Effects(Font(), justification), uuid.uuid4())
                            print_text_details(text, '1', 'horizontal')
                            schematic.texts.append(text)
                    elif (pin_angle == 0 or pin_angle == 180):
                        if (angle == 90 or angle == 270):
                            print("     Output: 90")
                            text_len = len(new_text_string)
                            if(pin_angle == 180 and angle == 270):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y + (text_len - 1)
                            if(pin_angle == 0 and angle == 90):
                                text_pin_X = sum_X - 0.1
                                # Adjust as needed for pin 1
                                text_pin_Y = sum_Y + (text_len - 1)
                            if(pin_angle == 180 and angle == 90):
                                text_pin_X = sum_X - 0.1
                                # Adjust as needed for pin 1
                                text_pin_Y = sum_Y - 0.1# (text_len - 1)
                            if(pin_angle == 0 and angle == 270):
                                text_pin_X = sum_X - 0.1
                                # Adjust as needed for pin 1
                                text_pin_Y = sum_Y - 0.1# (text_len - 1)
                            justification = Justify('left', 'bottom', 'center')
                            position = Position(X=round(text_pin_X,2), Y=round(text_pin_Y,2), angle=90)
                            text = Text(new_text_string, position, Effects(Font(), justification), uuid.uuid4())
                            print_text_details(text, '1', 'horizontal')
                            schematic.texts.append(text)
                        elif (angle == 0 or angle == 180):
                            print("     Output: 0")
                            len_txt = len(new_text_string)
                            if(pin_angle == 180 and angle == 0):
                                text_pin_X = sum_X - 0.1
                                text_pin_Y = sum_Y - 0.1
                            if(pin_angle == 180 and angle == 180):
                                text_pin_X = sum_X - (len_txt - 1)
                                text_pin_Y = sum_Y + 0.1
                            if(pin_angle == 0 and angle == 0):
                                text_pin_X = sum_X - (len_txt - 1)
                                text_pin_Y = sum_Y + 0.1
                            if(pin_angle == 0 and angle == 180):
                                text_pin_X = sum_X + 0.1
                                text_pin_Y = sum_Y + 0.1
                            justification = Justify('left', 'bottom', 'center')
                            position = Position(X=round(text_pin_X,2), Y=round(text_pin_Y,2), angle=0)
                            text = Text(new_text_string, position, Effects(Font(), justification), uuid.uuid4())
                            print_text_details(text, '1', 'horizontal')
                            schematic.texts.append(text)
                    added_positions.add(pos_key)

                else:
                    print("No symbol position found for {}".format(entryName))
            return schematic

        def extract_pin_positions(schematics):
            symbol_positions = []
            pin_positions = []

            for schematic in schematics:
                if hasattr(schematic, 'schematicSymbols'):
                    symbols = schematic.schematicSymbols
                    for symbol in symbols:
                        if hasattr(symbol, 'position'):
                            pos = symbol.position
                            symbol_positions.append(
                                (symbol.entryName, pos.X, pos.Y))

                if hasattr(schematic, 'libSymbols'):
                    symbols = schematic.libSymbols
                    for symbol in symbols:
                        units = symbol.units
                        for unit in units:
                            if hasattr(unit, 'pins'):
                                pins = unit.pins
                                for pin in pins:
                                    pos = pin.position
                                    pin_positions.append(
                                        (symbol.entryName, pin.number, pin.name, pos.X, pos.Y, pos.angle))

            return symbol_positions, pin_positions

        def main():
            parser = argparse.ArgumentParser(description="Parse KiCad schematic files, extract pin positions, and add text.")
            parser.add_argument('files', type=str, nargs='+',help='Schematic files to be parsed')
            parser.add_argument("--verbose", default=9,type=int, help="Debug print level")
            args = parser.parse_args()
            schematics = [Schematic().from_file(file) for file in args.files]
            symbol_positions, pin_positions = extract_pin_positions(schematics)
            symbol_pos_dict = {entryName: (X, Y)for entryName, X, Y in symbol_positions}
            ask = input("Do you want to add text? ").lower()
            if ask == "yes":
                new_text_string = input("Enter the text you want to add to each pin position: ").strip()
                for schematic, file_name in zip(schematics, args.files):
                    schematic = add_text_to_pins(schematic, new_text_string, Symbol_positions)
                    schematic.to_file(file_name)
                    print("Updated schematic saved to {}".format(file_name))

        if __name__ == "__main__":
            main()

    # Schematic sheet extraction is carried out here

    def extraction(schematics, debugprintlevel, file_names, Symbol_positions):
        '''
        1. Function will take the parsed file from the main function
        2. Function take the verbose level from main function
        3. As per the verbose level the results will be displayed

            :param schematics: The file path (1st argument)
            :param debugprintlevel: The print levels (0-13)
            :returns: The information as per the Verbose level

                :verbose 0: will print version of sheet
                :verbose 1: will print title block of sheet
                :verbose 2: will print No. of child sheets
                :verbose 3: will print No. of Symbols
                :verbose 4: will print Text Positions
                :verbose 5: will print Symbol positions
                :verbose 6: will print the Symbol properties
                :verbose 7: will print junction position
                :verbose 8: will print No. of labels if present
                :verbose 9: will print the position of lables
                :verbose 10: will print the No. of Lib Symbols
                :verbose 11: will print the properties of Lib Symbols
                :verbose 12: will print the passive position of the symbol pins
        '''

        symbol_positions = []
        pin_positions = []

        for schematic in schematics:
            if debugprintlevel > 0:
                print("Sheet information: ")
                if hasattr(schematic, 'version'):
                    print("     The version is:", schematic.version)
                if hasattr(schematic, 'titleBlock'):
                    print("     Title Block:", schematic.titleBlock)
                if hasattr(schematic, 'sheets'):
                    print("     The number of Hierarchical Sheets are:",len(schematic.sheets))
                    print("\n")

            # Extracting the info. for the symbols
            if hasattr(schematic, 'schematicSymbols'):
                symbols = schematic.schematicSymbols
                if debugprintlevel > 1:
                    print("Symbol Information: ")
                    print("     Number of Schematic Symbols:", len(symbols))
                    print("\n")

            for i, schematic in enumerate(schematics):
                # Extract and print existing text items
                if hasattr(schematic, 'texts'):
                    texts = schematic.texts
                    if debugprintlevel > 2:
                        if texts != 0:
                            print("Text information:")
                            for text in texts:
                                print("     Test: {}".format(text.text))
                                print("     Position: {}".format(text.position))
                                print("     UUID: {}".format(text.uuid))
                                print("\n")
                        else:
                            print("No Text's found.")
                            print("\n")

            if debugprintlevel > 3:
                print("Symbol Information: ")
            for symbol in symbols:
                # Extracts the symbol position
                if hasattr(symbol, 'position'):
                    pos = symbol.position
                    ref = symbol.properties
                    symbol_positions.append((symbol.entryName, pos.X, pos.Y))
                    if debugprintlevel > 3:
                        # print("Symbol Information: ")
                        print("     Entry Name: {}".format(symbol.entryName))
                        print("         Position X= {}".format(pos.X))
                        print("         Position Y= ".format(pos.Y))
                        print("         Symbol Properties: ")
                        for pro in ref:
                            print("             Key: {}".format(pro.key))
                            print("             Value: {}".format(pro.value))
                        print("\n")

            # Extract the junction details
            if hasattr(schematic, 'junctions'):
                junctions = schematic.junctions
                if debugprintlevel > 4:
                    print("Junction Information: ")
                    print("     Number Of Junctions: ", len(junctions))
                    for junction in junctions:
                        pos = junction.position
                        print("     Positions: ")
                        print("         X= ", pos.X)
                        print("         Y= ", pos.Y)
                        print("         UUID: ", junction.uuid)
                    print("\n")

            # Extracting the label details
            if hasattr(schematic, 'labels'):
                labels = schematic.labels
                if debugprintlevel > 5:
                    print("Label Information: ")
                    print("     Number of labels: ", len(labels))
                    for label in labels:
                        pos = label.position
                        print("     The label position is: X = ",
                              pos.X, ", Y = ", pos.Y)
                    print("\n")

            # Accessing the lib symbols
            if hasattr(schematic, 'libSymbols'):
                symbols = schematic.libSymbols
                if debugprintlevel > 6:
                    print("Lib Symbol Information: ")
                    print("     Number of lib symbols:", len(symbols))
                    for symbol in symbols:
                        # Extracting the symbol properties
                        properties = symbol.properties
                        for prop in properties:
                            print("     Property Key: ", prop.key)
                            print("     Property Value: ", prop.value)
                    print("\n")

            for schematic in schematics:
                for symbol in symbols:
                    units = symbol.units
                    if debugprintlevel > 7:
                        print("Pin Information: ")
                        print("     Symbol: ", symbol.entryName)
                        for unit in units:
                            # Gives the pin details
                            if hasattr(unit, 'pins'):
                                pins = unit.pins
                                for pin in pins:
                                    pos = pin.position
                                    pin_positions.append(
                                        (symbol.entryName, pin.number, pin.name, pos.X, pos.Y, pos.angle))
                                    print("     Pin: " + str(pin.number))
                                    print("     Pin Name: ", pin.name)
                                    print("     Passive Position: X = " + str(pos.X) +", Y = " + str(pos.Y) + ", Angle = " + str(pos.angle))
                                    print("\n")

            # Adding new text functionality if debug level is exactly 5
            if debugprintlevel > 8:
                add_text_to_schematic(
                    schematic, file_names[i], Symbol_positions)

        return symbol_positions, pin_positions

    # Main function to parse schematic files
    def main():
        '''
            1. This function will fetch the file from the given path of the file.
            2. It will also take the verbose from user
            3. Then the file will be parsed
            4. Then the parsed file will be passed to the extraction function
        '''

        parser = argparse.ArgumentParser(
            description="Parse KiCad schematic files and extract information.")
        parser.add_argument('files', type=str, nargs='+',help='Schematic files to be parsed')
        parser.add_argument("--verbose", default=9,type=int, help="Debug print level")

        args = parser.parse_args()
        debugprintlevel = args.verbose
        schematics = [Schematic().from_file(file) for file in args.files]
        # print(schematics)
        lib_positions, pin_pos = extract_pin_positions(schematics)
        # print(pin_pos.angle)
        # print_pin_information(lib_positions, pin_pos)
        printed_libs = set()
        symbol_positions = []

        for libId, (lib_X, lib_Y, lib_angle) in lib_positions.items():
            if libId not in printed_libs:
                print("Library ID: {}".format(libId))
                print("  Position: X = {}, Y = {}, Angle = {}".format(lib_X, lib_Y, lib_angle))
                print("  Pins:")
                for pin_libId, pin_number, pin_name, pin_X, pin_Y, pin_angle in pin_pos:
                    if pin_libId == libId:
                        # Rotate pin position relative to symbol
                        rotated_X, rotated_Y = rotate_point(pin_X, pin_Y, lib_angle)
                        # Sum positions to get the absolute position
                        sum_X = round((lib_X + rotated_X), 2)
                        sum_Y = round((lib_Y + rotated_Y), 2)

                        # if(pin_X < 0):
                        # sum_X = lib_X - pin_X
                        # else:
                        # sum_X = lib_X + pin_X
                        # if(pin_Y < 0):
                        # sum_Y = lib_Y - pin_Y
                       # else:
                        # sum_Y = lib_Y + pin_Y

                        symbol_positions.append((libId, sum_X, sum_Y, lib_angle, pin_angle))
                        print("    Pin {}: Value = {}, X = {}, Y = {}, Angle = {}".format(pin_number, pin_name, sum_X, sum_Y, pin_angle))
                print()  # Print a blank line for separation between library IDs
                printed_libs.add(libId)

        symbol_position, pin_position = extraction(schematics, debugprintlevel, args.files, symbol_positions)
        ''' 1. This is the where the main function is called. '''
    main()


if __name__ == "__main__":
    schematic_extraction_details()
